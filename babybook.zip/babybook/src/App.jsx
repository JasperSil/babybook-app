import { useState, useEffect, useRef } from "react";

// ─── SUPABASE CONFIG ───────────────────────────────────────────
const SUPABASE_URL = "https://xnlblcggvppdwalcxoos.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhubGJsY2dndnBwZHdhbGN4b29zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY1MDc5NTgsImV4cCI6MjA5MjA4Mzk1OH0.D1hG0-Bh_MQe3QJUsgoKGxijd0UDLAv9HtVTB8rsyI8";

const sb = {
  // Haal posts op, nieuwste eerst
  async getPosts() {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/posts?select=*&order=created_at.desc`, {
      headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
    });
    return res.json();
  },

  // Sla een nieuwe post op
  async createPost(post) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/posts`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "application/json",
        Prefer: "return=representation"
      },
      body: JSON.stringify(post)
    });
    const data = await res.json();
    return data[0];
  },

  // Upload foto naar Supabase Storage
  async uploadPhoto(file) {
    const ext = file.name.split(".").pop();
    const filename = `${Date.now()}.${ext}`;
    const res = await fetch(`${SUPABASE_URL}/storage/v1/object/post-images/${filename}`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        "Content-Type": file.type
      },
      body: file
    });
    if (!res.ok) return null;
    return `${SUPABASE_URL}/storage/v1/object/public/post-images/${filename}`;
  },

  // Haal reacties op voor een post
  async getComments(postId) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/comments?post_id=eq.${postId}&order=created_at.asc`, {
      headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
    });
    return res.json();
  },

  // Sla een reactie op
  async createComment(postId, text) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/comments`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "application/json",
        Prefer: "return=representation"
      },
      body: JSON.stringify({ post_id: postId, content: text, user_id: MOCK_USER.id })
    });
    const data = await res.json();
    return data[0];
  }
};

// ─── MOCK USER (later vervangen door echte auth) ───────────────
const MOCK_USER = {
  id: "00000000-0000-0000-0000-000000000001",
  name: "Sophie van den Berg",
  weeksPregnant: 24,
};

const MILESTONES = [
  { week: 6, label: "Hartslag gehoord", done: true },
  { week: 12, label: "1e trimester voorbij", done: true },
  { week: 16, label: "Geslacht bekend?", done: true },
  { week: 20, label: "Grote echo", done: true },
  { week: 24, label: "Nu", done: true, current: true },
  { week: 28, label: "Suikertest", done: false },
  { week: 32, label: "3e trimester", done: false },
  { week: 36, label: "Bijna daar!", done: false },
  { week: 40, label: "Uitgerekend!", done: false },
];

const POST_TYPES = [
  { type: "echo", label: "Echo", icon: "🩻", color: "#F0F4FF" },
  { type: "moment", label: "Moment", icon: "✨", color: "#F0FDF4" },
  { type: "foto", label: "Foto", icon: "📷", color: "#FFFBF0" },
  { type: "gevoel", label: "Gevoel", icon: "💭", color: "#F5F0FF" },
  { type: "meting", label: "Meting", icon: "📏", color: "#F0F8FF" },
];

const AI_TIPS = [
  { tip: "Je baby kan nu geluiden horen. Praat of zing gerust tegen je buik.", category: "Baby ontwikkeling" },
  { tip: "Denk na over je geboorteplan. Schrijf je wensen op — ook voor je partner.", category: "Praktisch" },
  { tip: "Rugpijn is normaal in week 24. Zwemmen of zachte yoga kan helpen.", category: "Jouw lichaam" },
];

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "Zojuist";
  if (m < 60) return `${m}m geleden`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}u geleden`;
  const d = Math.floor(h / 24);
  if (d === 1) return "Gisteren";
  return `${d} dagen geleden`;
}

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Outfit:wght@300;400;500;600&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --white: #ffffff; --bg: #FAFAF9;
    --border: #EEECE9; --border2: #E2DDD8;
    --text: #1C1917; --text2: #6B6560; --text3: #A8A29E;
    --accent: #C8956C; --accent-light: #FDF5EE; --accent-dark: #A0704A;
    --green: #4A7C59; --green-light: #F0F7F3;
  }
  body { font-family: 'Outfit', sans-serif; background: var(--bg); color: var(--text); -webkit-font-smoothing: antialiased; }
  .app { max-width: 430px; margin: 0 auto; min-height: 100vh; background: var(--bg); }
  .header { background: var(--white); padding: 16px 20px 0; border-bottom: 1px solid var(--border); position: sticky; top: 0; z-index: 100; }
  .header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
  .logo { font-family: 'Lora', serif; font-size: 19px; color: var(--text); cursor: pointer; }
  .logo em { font-style: italic; color: var(--accent-dark); }
  .hdr-btns { display: flex; gap: 8px; }
  .hdr-btn { width: 34px; height: 34px; border-radius: 50%; background: var(--bg); border: 1px solid var(--border2); cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 14px; color: var(--text2); font-family:'Outfit',sans-serif; font-weight:500; transition: all 0.15s; }
  .hdr-btn:hover { border-color: var(--accent); color: var(--accent-dark); }
  .prog-wrap { background: var(--white); border: 1px solid var(--border); border-radius: 12px; padding: 13px 15px; margin-bottom: 12px; }
  .prog-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 9px; }
  .prog-label { font-size: 12px; font-weight: 500; color: var(--text2); }
  .week-pill { background: var(--accent-light); color: var(--accent-dark); padding: 2px 9px; border-radius: 20px; font-size: 11px; font-weight: 600; border: 1px solid rgba(200,149,108,0.25); }
  .prog-bar { height: 3px; background: var(--border); border-radius: 10px; overflow: hidden; margin-bottom: 7px; }
  .prog-fill { height: 100%; background: linear-gradient(90deg, var(--accent), var(--accent-dark)); border-radius: 10px; }
  .prog-sub { display: flex; justify-content: space-between; font-size: 10px; color: var(--text3); }
  .tabs { display: flex; }
  .tab { flex: 1; padding: 9px 4px; border: none; background: transparent; font-family:'Outfit',sans-serif; font-size: 11px; color: var(--text3); cursor: pointer; border-bottom: 2px solid transparent; display: flex; flex-direction: column; align-items: center; gap: 3px; transition: all 0.15s; }
  .tab.active { color: var(--text); border-bottom-color: var(--accent-dark); }
  .tab-ic { font-size: 16px; }
  .content { padding: 14px; padding-bottom: 86px; }
  .compose-bar { background: var(--white); border: 1px solid var(--border); border-radius: 14px; padding: 11px 13px; display: flex; align-items: center; gap: 10px; margin-bottom: 14px; cursor: pointer; transition: border-color 0.15s; }
  .compose-bar:hover { border-color: var(--accent); }
  .av-s { width: 34px; height: 34px; border-radius: 50%; background: var(--accent-light); display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 600; color: var(--accent-dark); flex-shrink: 0; border: 1px solid rgba(200,149,108,0.25); }
  .compose-ph { flex: 1; font-size: 12px; color: var(--text3); }
  .compose-plus { width: 26px; height: 26px; border-radius: 50%; background: var(--text); display: flex; align-items: center; justify-content: center; color: white; font-size: 16px; }
  .post { background: var(--white); border: 1px solid var(--border); border-radius: 16px; margin-bottom: 10px; overflow: hidden; animation: up 0.25s ease; }
  @keyframes up { from { opacity:0; transform:translateY(6px);} to { opacity:1; transform:translateY(0);} }
  .post-hdr { padding: 13px 15px 10px; display: flex; align-items: center; gap: 10px; }
  .post-ic { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0; }
  .post-meta { flex: 1; }
  .post-name { font-weight: 500; font-size: 13px; color: var(--text); }
  .post-when { font-size: 11px; color: var(--text3); margin-top: 1px; }
  .post-tags { display: flex; flex-direction: column; gap: 3px; align-items: flex-end; }
  .tag-week { background: var(--bg); color: var(--text2); padding: 2px 7px; border-radius: 20px; font-size: 10px; font-weight: 500; border: 1px solid var(--border2); }
  .tag-ms { background: var(--accent-light); color: var(--accent-dark); padding: 2px 7px; border-radius: 20px; font-size: 10px; font-weight: 600; border: 1px solid rgba(200,149,108,0.25); }
  .post-photo { width: 100%; max-height: 280px; object-fit: cover; display: block; }
  .post-emoji-bg { width: 100%; height: 140px; display: flex; align-items: center; justify-content: center; font-size: 48px; }
  .post-body { padding: 11px 15px; }
  .post-title { font-family: 'Lora', serif; font-size: 15px; color: var(--text); margin-bottom: 4px; }
  .post-txt { font-size: 13px; line-height: 1.65; color: var(--text2); font-weight: 300; }
  .post-acts { padding: 9px 15px; border-top: 1px solid var(--border); display: flex; gap: 2px; }
  .act-btn { display: flex; align-items: center; gap: 4px; background: none; border: none; font-family:'Outfit',sans-serif; font-size: 12px; color: var(--text3); cursor: pointer; padding: 5px 9px; border-radius: 8px; transition: all 0.15s; }
  .act-btn:hover { background: var(--bg); color: var(--text2); }
  .act-btn.liked { color: #D94F4F; }
  .act-ml { margin-left: auto; }
  .cmts-wrap { padding: 0 15px 10px; }
  .cmt { display: flex; gap: 7px; margin-bottom: 7px; }
  .cmt-av { width: 24px; height: 24px; border-radius: 50%; background: var(--bg); border: 1px solid var(--border2); display: flex; align-items: center; justify-content: center; font-size: 9px; color: var(--text2); font-weight: 600; flex-shrink: 0; }
  .cmt-bub { background: var(--bg); border-radius: 9px 9px 9px 2px; padding: 6px 10px; flex: 1; }
  .cmt-author { font-size: 10px; font-weight: 600; color: var(--text); }
  .cmt-txt { font-size: 12px; color: var(--text2); line-height: 1.4; }
  .cmt-row { display: flex; gap: 7px; align-items: center; padding: 0 15px 13px; }
  .cmt-in { flex: 1; background: var(--bg); border: 1px solid var(--border2); border-radius: 18px; padding: 6px 13px; font-family:'Outfit',sans-serif; font-size: 12px; color: var(--text); outline: none; transition: border-color 0.15s; }
  .cmt-in:focus { border-color: var(--accent); }
  .cmt-send { width: 28px; height: 28px; border-radius: 50%; background: var(--text); border: none; color: white; cursor: pointer; font-size: 11px; }
  .tl-item { display: flex; gap: 12px; margin-bottom: 16px; position: relative; }
  .tl-item::before { content: ''; position: absolute; left: 18px; top: 40px; bottom: -16px; width: 1px; background: var(--border2); }
  .tl-item:last-child::before { display: none; }
  .tl-dot { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 17px; flex-shrink: 0; z-index: 1; border: 1px solid var(--border); }
  .tl-card { flex: 1; background: var(--white); border: 1px solid var(--border); border-radius: 12px; padding: 11px 13px; }
  .tl-wk { font-size: 10px; color: var(--text3); margin-bottom: 2px; }
  .tl-title { font-family: 'Lora', serif; font-size: 13px; color: var(--text); }
  .tl-txt { font-size: 11px; color: var(--text2); line-height: 1.5; margin-top: 3px; }
  .card { background: var(--white); border: 1px solid var(--border); border-radius: 16px; padding: 16px; margin-bottom: 10px; }
  .card-title { font-family: 'Lora', serif; font-size: 16px; color: var(--text); margin-bottom: 14px; }
  .ms-row { display: flex; align-items: center; gap: 11px; padding: 9px 11px; border-radius: 10px; margin-bottom: 3px; }
  .ms-row.done { background: var(--green-light); }
  .ms-row.current { background: var(--accent-light); border: 1px solid rgba(200,149,108,0.2); }
  .ms-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }
  .ms-dot.done { background: var(--green); }
  .ms-dot.current { background: var(--accent-dark); }
  .ms-dot.future { background: var(--border2); }
  .ms-info { flex: 1; }
  .ms-wk { font-size: 10px; color: var(--text3); }
  .ms-lbl { font-size: 13px; font-weight: 500; color: var(--text); }
  .ms-chk { font-size: 13px; color: var(--text3); }
  .ai-hdr { background: var(--white); border: 1px solid var(--border); border-radius: 16px; padding: 20px; margin-bottom: 10px; text-align: center; }
  .ai-icon { font-size: 32px; margin-bottom: 8px; }
  .ai-title { font-family: 'Lora', serif; font-size: 17px; color: var(--text); }
  .ai-sub { font-size: 12px; color: var(--text2); margin-top: 3px; }
  .pro-pill { background: var(--accent-light); color: var(--accent-dark); padding: 3px 9px; border-radius: 20px; font-size: 10px; font-weight: 600; display: inline-block; margin-top: 8px; border: 1px solid rgba(200,149,108,0.25); }
  .tip-card { background: var(--white); border: 1px solid var(--border); border-radius: 14px; padding: 13px 15px; margin-bottom: 9px; }
  .tip-cat { font-size: 10px; font-weight: 600; color: var(--text3); text-transform: uppercase; letter-spacing: 0.7px; margin-bottom: 5px; }
  .tip-txt { font-size: 13px; color: var(--text); line-height: 1.6; font-weight: 300; }
  .ai-ask { background: var(--white); border: 1px dashed var(--border2); border-radius: 14px; padding: 15px; }
  .ai-ask-lbl { font-size: 12px; color: var(--text2); margin-bottom: 9px; }
  .ai-in { width: 100%; background: var(--bg); border: 1px solid var(--border2); border-radius: 9px; padding: 9px 13px; font-family:'Outfit',sans-serif; font-size: 12px; color: var(--text); outline: none; margin-bottom: 9px; }
  .pro-btn { width: 100%; padding: 11px; background: var(--text); color: white; border: none; border-radius: 9px; font-family:'Outfit',sans-serif; font-size: 13px; font-weight: 500; cursor: pointer; transition: background 0.15s; }
  .pro-btn:hover { background: var(--accent-dark); }
  .prof-hdr { background: var(--white); border: 1px solid var(--border); border-radius: 16px; padding: 22px; text-align: center; margin-bottom: 10px; }
  .av-lg { width: 68px; height: 68px; border-radius: 50%; background: var(--accent-light); margin: 0 auto 10px; display: flex; align-items: center; justify-content: center; font-size: 26px; font-weight: 600; color: var(--accent-dark); border: 2px solid rgba(200,149,108,0.25); }
  .prof-name { font-family: 'Lora', serif; font-size: 19px; color: var(--text); }
  .prof-sub { font-size: 11px; color: var(--text3); margin-top: 2px; }
  .prof-stats { display: flex; justify-content: center; gap: 30px; margin-top: 14px; padding-top: 14px; border-top: 1px solid var(--border); }
  .stat-n { font-family: 'Lora', serif; font-size: 20px; color: var(--text); font-weight: 600; }
  .stat-l { font-size: 10px; color: var(--text3); margin-top: 1px; text-transform: uppercase; letter-spacing: 0.5px; }
  .foll-card { background: var(--white); border: 1px solid var(--border); border-radius: 16px; padding: 16px; }
  .sec-title { font-size: 11px; font-weight: 600; color: var(--text3); text-transform: uppercase; letter-spacing: 0.7px; margin-bottom: 11px; }
  .foll-row { display: flex; align-items: center; gap: 9px; padding: 7px 0; border-bottom: 1px solid var(--border); }
  .foll-row:last-of-type { border-bottom: none; }
  .foll-av { width: 32px; height: 32px; border-radius: 50%; background: var(--bg); border: 1px solid var(--border2); display: flex; align-items: center; justify-content: center; font-size: 11px; color: var(--text2); font-weight: 600; }
  .foll-name { flex: 1; font-size: 13px; color: var(--text); font-weight: 500; }
  .foll-role { font-size: 10px; color: var(--text3); background: var(--bg); padding: 2px 7px; border-radius: 20px; border: 1px solid var(--border2); }
  .inv-btn { width: 100%; margin-top: 11px; padding: 9px; background: transparent; border: 1px solid var(--border2); border-radius: 9px; color: var(--text2); font-family:'Outfit',sans-serif; font-size: 12px; cursor: pointer; transition: all 0.15s; }
  .inv-btn:hover { border-color: var(--accent); color: var(--accent-dark); }
  .modal-ov { position: fixed; inset: 0; background: rgba(28,25,23,0.45); z-index: 200; display: flex; align-items: flex-end; }
  .modal { background: var(--bg); border-radius: 20px 20px 0 0; padding: 18px; width: 100%; max-height: 92vh; overflow-y: auto; }
  .modal-handle { width: 30px; height: 3px; background: var(--border2); border-radius: 2px; margin: 0 auto 14px; }
  .modal-title { font-family: 'Lora', serif; font-size: 19px; color: var(--text); margin-bottom: 14px; }
  .type-grid { display: grid; grid-template-columns: repeat(5,1fr); gap: 7px; margin-bottom: 14px; }
  .type-btn { border: 1.5px solid var(--border2); border-radius: 9px; padding: 9px 4px; display: flex; flex-direction: column; align-items: center; gap: 3px; cursor: pointer; font-family:'Outfit',sans-serif; font-size: 10px; font-weight: 500; color: var(--text2); background: var(--white); transition: all 0.15s; }
  .type-btn.sel { border-color: var(--accent-dark); background: var(--accent-light); color: var(--accent-dark); }
  .type-ic { font-size: 18px; }
  .fg { margin-bottom: 12px; }
  .fl { font-size: 10px; font-weight: 600; color: var(--text3); text-transform: uppercase; letter-spacing: 0.6px; margin-bottom: 5px; display: block; }
  .fi, .fta { width: 100%; background: var(--white); border: 1px solid var(--border2); border-radius: 9px; padding: 9px 13px; font-family:'Outfit',sans-serif; font-size: 13px; color: var(--text); outline: none; transition: border-color 0.15s; }
  .fi:focus, .fta:focus { border-color: var(--accent); }
  .fta { height: 90px; resize: none; }
  .photo-upload { width: 100%; height: 110px; border: 1.5px dashed var(--border2); border-radius: 9px; display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: pointer; gap: 6px; transition: border-color 0.15s; background: var(--white); }
  .photo-upload:hover { border-color: var(--accent); }
  .photo-preview { width: 100%; height: 110px; object-fit: cover; border-radius: 9px; display: block; }
  .sub-btn { width: 100%; padding: 13px; background: var(--text); color: white; border: none; border-radius: 9px; font-family:'Outfit',sans-serif; font-size: 14px; font-weight: 500; cursor: pointer; margin-top: 4px; transition: background 0.15s; }
  .sub-btn:hover { background: var(--accent-dark); }
  .sub-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .bot-nav { position: fixed; bottom: 0; left: 50%; transform: translateX(-50%); width: 100%; max-width: 430px; background: var(--white); border-top: 1px solid var(--border); display: flex; padding: 8px 0 16px; z-index: 100; }
  .bnav-tab { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 2px; background: none; border: none; cursor: pointer; font-family:'Outfit',sans-serif; font-size: 10px; color: var(--text3); padding: 4px 0; transition: color 0.15s; }
  .bnav-tab.active { color: var(--text); }
  .bnav-ic { font-size: 19px; }
  .fab { width: 46px; height: 46px; border-radius: 50%; background: var(--text); border: none; color: white; font-size: 20px; cursor: pointer; box-shadow: 0 3px 12px rgba(28,25,23,0.18); display: flex; align-items: center; justify-content: center; margin-top: -7px; transition: all 0.2s; }
  .fab:hover { background: var(--accent-dark); transform: scale(1.06); }
  .loading { display: flex; align-items: center; justify-content: center; padding: 40px; flex-direction: column; gap: 10px; color: var(--text3); font-size: 13px; }
  .spinner { width: 24px; height: 24px; border: 2px solid var(--border2); border-top-color: var(--accent); border-radius: 50%; animation: spin 0.7s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .empty { text-align: center; padding: 40px 20px; color: var(--text3); }
  .empty-ic { font-size: 36px; margin-bottom: 10px; }
  .empty-txt { font-size: 13px; line-height: 1.6; }
  .toast { position: fixed; bottom: 84px; left: 50%; transform: translateX(-50%); background: var(--text); color: white; padding: 9px 16px; border-radius: 18px; font-size: 12px; z-index: 300; white-space: nowrap; box-shadow: 0 4px 16px rgba(28,25,23,0.15); animation: tin 0.2s ease; }
  @keyframes tin { from { opacity:0; transform:translateX(-50%) translateY(5px);} to { opacity:1; transform:translateX(-50%) translateY(0);} }
  .err-banner { background: #FFF0F0; border: 1px solid #FFCDD2; border-radius: 10px; padding: 10px 14px; margin-bottom: 12px; font-size: 12px; color: #C62828; }
`;

// ─── POST COMPONENT ────────────────────────────────────────────
function Post({ post, onLike }) {
  const [showCmts, setShowCmts] = useState(false);
  const [cmts, setCmts] = useState([]);
  const [val, setVal] = useState("");
  const [loadingCmts, setLoadingCmts] = useState(false);

  const typeInfo = POST_TYPES.find(t => t.type === post.type) || POST_TYPES[1];

  const loadComments = async () => {
    if (showCmts) { setShowCmts(false); return; }
    setShowCmts(true);
    setLoadingCmts(true);
    const data = await sb.getComments(post.id);
    setCmts(Array.isArray(data) ? data : []);
    setLoadingCmts(false);
  };

  const send = async () => {
    if (!val.trim()) return;
    const saved = await sb.createComment(post.id, val);
    setCmts(prev => [...prev, saved || { id: Date.now(), content: val, user_id: MOCK_USER.id, created_at: new Date().toISOString() }]);
    setVal("");
  };

  return (
    <div className="post">
      <div className="post-hdr">
        <div className="post-ic" style={{ background: typeInfo.color }}>{typeInfo.icon}</div>
        <div className="post-meta">
          <div className="post-name">{MOCK_USER.name}</div>
          <div className="post-when">{timeAgo(post.created_at)}</div>
        </div>
        <div className="post-tags">
          {post.week_number && <span className="tag-week">Week {post.week_number}</span>}
          {post.is_milestone && <span className="tag-ms">Milestone</span>}
        </div>
      </div>

      {post.image_url
        ? <img className="post-photo" src={post.image_url} alt={post.title} />
        : <div className="post-emoji-bg" style={{ background: typeInfo.color }}>{typeInfo.icon}</div>
      }

      <div className="post-body">
        <div className="post-title">{post.title}</div>
        <div className="post-txt">{post.content}</div>
      </div>

      <div className="post-acts">
        <button className={`act-btn ${post.liked ? "liked" : ""}`} onClick={() => onLike(post.id)}>
          {post.liked ? "♥" : "♡"} {post.likes_count || 0}
        </button>
        <button className="act-btn" onClick={loadComments}>
          💬 {showCmts ? "Verberg" : "Reacties"}
        </button>
        <button className="act-btn act-ml">↗ Deel</button>
      </div>

      {showCmts && <>
        <div className="cmts-wrap">
          {loadingCmts
            ? <div style={{ fontSize: 12, color: "var(--text3)", padding: "4px 0" }}>Laden…</div>
            : cmts.length === 0
              ? <div style={{ fontSize: 12, color: "var(--text3)", padding: "4px 0" }}>Nog geen reacties. Wees de eerste!</div>
              : cmts.map(c => (
                <div key={c.id} className="cmt">
                  <div className="cmt-av">{(c.user_id || "?")[0].toUpperCase()}</div>
                  <div className="cmt-bub">
                    <div className="cmt-author">Familie</div>
                    <div className="cmt-txt">{c.content}</div>
                  </div>
                </div>
              ))
          }
        </div>
        <div className="cmt-row">
          <input className="cmt-in" placeholder="Reageer…" value={val}
            onChange={e => setVal(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()} />
          <button className="cmt-send" onClick={send}>➤</button>
        </div>
      </>}
    </div>
  );
}

// ─── MODAL: NIEUW MOMENT ───────────────────────────────────────
function Modal({ onClose, onPost }) {
  const [type, setType] = useState("moment");
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [photo, setPhoto] = useState(null);
  const [preview, setPreview] = useState(null);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef();

  const pickPhoto = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setPhoto(file);
    setPreview(URL.createObjectURL(file));
  };

  const submit = async () => {
    if (!title || !text) return;
    setSaving(true);
    try {
      let imageUrl = null;
      if (photo) {
        imageUrl = await sb.uploadPhoto(photo);
      }
      const typeInfo = POST_TYPES.find(p => p.type === type);
      const saved = await sb.createPost({
        user_id: MOCK_USER.id,
        type,
        title,
        content: text,
        week_number: MOCK_USER.weeksPregnant,
        image_url: imageUrl,
        is_milestone: false,
      });
      onPost(saved || { id: Date.now(), type, title, content: text, week_number: MOCK_USER.weeksPregnant, image_url: imageUrl, is_milestone: false, created_at: new Date().toISOString(), likes_count: 0 });
      onClose();
    } catch (e) {
      console.error(e);
    }
    setSaving(false);
  };

  return (
    <div className="modal-ov" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-handle" />
        <div className="modal-title">Nieuw moment</div>

        <div className="fg">
          <label className="fl">Type</label>
          <div className="type-grid">
            {POST_TYPES.map(p => (
              <button key={p.type} className={`type-btn ${type === p.type ? "sel" : ""}`} onClick={() => setType(p.type)}>
                <span className="type-ic">{p.icon}</span>{p.label}
              </button>
            ))}
          </div>
        </div>

        <div className="fg">
          <label className="fl">Foto (optioneel)</label>
          <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={pickPhoto} />
          {preview
            ? <div style={{ position: "relative" }}>
                <img src={preview} className="photo-preview" alt="preview" />
                <button onClick={() => { setPhoto(null); setPreview(null); }}
                  style={{ position: "absolute", top: 6, right: 6, background: "rgba(0,0,0,0.5)", border: "none", color: "white", borderRadius: "50%", width: 24, height: 24, cursor: "pointer", fontSize: 12 }}>✕</button>
              </div>
            : <div className="photo-upload" onClick={() => fileRef.current.click()}>
                <span style={{ fontSize: 24 }}>📷</span>
                <span style={{ fontSize: 12, color: "var(--text3)" }}>Tik om een foto toe te voegen</span>
              </div>
          }
        </div>

        <div className="fg">
          <label className="fl">Titel</label>
          <input className="fi" placeholder="bijv. Echo week 20" value={title} onChange={e => setTitle(e.target.value)} />
        </div>

        <div className="fg">
          <label className="fl">Jouw verhaal</label>
          <textarea className="fta" placeholder="Deel dit bijzondere moment…" value={text} onChange={e => setText(e.target.value)} />
        </div>

        <button className="sub-btn" onClick={submit} disabled={saving}>
          {saving ? "Opslaan…" : "Delen met familie & vrienden"}
        </button>
      </div>
    </div>
  );
}

// ─── MAIN APP ──────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("feed");
  const [nav, setNav] = useState("home");
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modal, setModal] = useState(false);
  const [toast, setToast] = useState(null);

  const showToast = m => { setToast(m); setTimeout(() => setToast(null), 2200); };

  // Posts laden uit Supabase
  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await sb.getPosts();
      if (Array.isArray(data)) {
        setPosts(data);
      } else {
        setError("Kon posts niet laden. Controleer of de tabellen zijn aangemaakt in Supabase.");
      }
    } catch (e) {
      setError("Verbindingsfout met Supabase.");
    }
    setLoading(false);
  };

  const like = id => setPosts(posts.map(p => p.id === id ? { ...p, liked: !p.liked, likes_count: (p.likes_count || 0) + (p.liked ? -1 : 1) } : p));

  const addPost = p => {
    setPosts(prev => [p, ...prev]);
    showToast("✓ Opgeslagen en gedeeld!");
  };

  const prog = (MOCK_USER.weeksPregnant / 40) * 100;

  return (
    <>
      <style>{css}</style>
      <div className="app">

        {/* HEADER */}
        <div className="header">
          <div className="header-top">
            <div className="logo" onClick={() => { setNav("home"); setTab("feed"); }}>baby<em>book</em></div>
            <div className="hdr-btns">
              <button className="hdr-btn" onClick={loadPosts} title="Vernieuwen">↻</button>
              <button className="hdr-btn" onClick={() => setNav("profile")}>S</button>
            </div>
          </div>
          {nav === "home" && (
            <div className="prog-wrap">
              <div className="prog-top">
                <span className="prog-label">Zwangerschap</span>
                <span className="week-pill">Week {MOCK_USER.weeksPregnant} van 40</span>
              </div>
              <div className="prog-bar"><div className="prog-fill" style={{ width: `${prog}%` }} /></div>
              <div className="prog-sub"><span>Begin</span><span>Nog {40 - MOCK_USER.weeksPregnant} weken</span><span>Week 40</span></div>
            </div>
          )}
          {nav === "home" && (
            <div className="tabs">
              {[{ id: "feed", ic: "⊞", lbl: "Feed" }, { id: "timeline", ic: "◎", lbl: "Tijdlijn" }, { id: "milestones", ic: "◈", lbl: "Mijlpalen" }, { id: "ai", ic: "✦", lbl: "AI Tips" }].map(t => (
                <button key={t.id} className={`tab ${tab === t.id ? "active" : ""}`} onClick={() => setTab(t.id)}>
                  <span className="tab-ic">{t.ic}</span>{t.lbl}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* CONTENT */}
        <div className="content">

          {/* FEED */}
          {nav === "home" && tab === "feed" && <>
            <div className="compose-bar" onClick={() => setModal(true)}>
              <div className="av-s">S</div>
              <div className="compose-ph">Deel een moment van je zwangerschap…</div>
              <div className="compose-plus">+</div>
            </div>
            {error && <div className="err-banner">⚠️ {error}</div>}
            {loading
              ? <div className="loading"><div className="spinner" /><span>Momenten laden…</span></div>
              : posts.length === 0
                ? <div className="empty">
                    <div className="empty-ic">🌱</div>
                    <div className="empty-txt">Nog geen momenten gedeeld.<br />Voeg je eerste moment toe!</div>
                  </div>
                : posts.map(p => <Post key={p.id} post={p} onLike={like} />)
            }
          </>}

          {/* TIJDLIJN */}
          {nav === "home" && tab === "timeline" && <>
            <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 14, fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.6px" }}>
              Meest recent eerst — scroll voor eerdere momenten
            </div>
            {loading
              ? <div className="loading"><div className="spinner" /></div>
              : [...posts].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).map(p => {
                  const t = POST_TYPES.find(pt => pt.type === p.type) || POST_TYPES[1];
                  return (
                    <div key={p.id} className="tl-item">
                      <div className="tl-dot" style={{ background: t.color }}>{t.icon}</div>
                      <div className="tl-card">
                        <div className="tl-wk">{p.week_number ? `Week ${p.week_number} · ` : ""}{timeAgo(p.created_at)}</div>
                        <div className="tl-title">{p.title}</div>
                        <div className="tl-txt">{(p.content || "").substring(0, 75)}{p.content?.length > 75 ? "…" : ""}</div>
                      </div>
                    </div>
                  );
                })
            }
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0 4px", opacity: 0.45 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: "var(--border)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🌱</div>
              <div>
                <div style={{ fontSize: 10, color: "var(--text3)" }}>Week 1</div>
                <div style={{ fontSize: 13, fontFamily: "Lora, serif", color: "var(--text2)" }}>Het begin van je zwangerschapsreis</div>
              </div>
            </div>
          </>}

          {/* MIJLPALEN */}
          {nav === "home" && tab === "milestones" && (
            <div className="card">
              <div className="card-title">Jouw zwangerschapsreis</div>
              {MILESTONES.map((m, i) => (
                <div key={i} className={`ms-row ${m.current ? "current" : m.done ? "done" : ""}`}>
                  <div className={`ms-dot ${m.current ? "current" : m.done ? "done" : "future"}`} />
                  <div className="ms-info">
                    <div className="ms-wk">Week {m.week}</div>
                    <div className="ms-lbl">{m.label}</div>
                  </div>
                  <div className="ms-chk">{m.current ? "→" : m.done ? "✓" : ""}</div>
                </div>
              ))}
            </div>
          )}

          {/* AI TIPS */}
          {nav === "home" && tab === "ai" && <>
            <div className="ai-hdr">
              <div className="ai-icon">✦</div>
              <div className="ai-title">AI Zwangerschap Coach</div>
              <div className="ai-sub">Persoonlijke tips voor week {MOCK_USER.weeksPregnant}</div>
              <span className="pro-pill">PRO Feature</span>
            </div>
            {AI_TIPS.map((t, i) => (
              <div key={i} className="tip-card">
                <div className="tip-cat">{t.category}</div>
                <div className="tip-txt">{t.tip}</div>
              </div>
            ))}
            <div className="ai-ask">
              <div className="ai-ask-lbl">Stel je eigen vraag aan de AI coach</div>
              <input className="ai-in" placeholder="bijv. Is rugpijn normaal in week 24?" />
              <button className="pro-btn" onClick={() => showToast("Upgrade naar Pro voor AI vragen")}>Upgrade naar Pro — €4,99 / maand</button>
            </div>
          </>}

          {/* PROFIEL */}
          {nav === "profile" && <>
            <div className="prof-hdr">
              <div className="av-lg">S</div>
              <div className="prof-name">{MOCK_USER.name}</div>
              <div className="prof-sub">Uitgerekend 15 oktober · Week {MOCK_USER.weeksPregnant}</div>
              <div className="prof-stats">
                {[{ n: posts.length, l: "Berichten" }, { n: 5, l: "Volgers" }, { n: MOCK_USER.weeksPregnant, l: "Weken" }].map((s, i) => (
                  <div key={i} style={{ textAlign: "center" }}>
                    <div className="stat-n">{s.n}</div>
                    <div className="stat-l">{s.l}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="foll-card">
              <div className="sec-title">Familie & vrienden</div>
              {[{ n: "Mama", r: "Familie", a: "M" }, { n: "Papa", r: "Familie", a: "P" }, { n: "Zus Emma", r: "Familie", a: "E" }, { n: "Tante Lisa", r: "Familie", a: "L" }, { n: "Vriendin Noor", r: "Vriend", a: "N" }].map((f, i) => (
                <div key={i} className="foll-row">
                  <div className="foll-av">{f.a}</div>
                  <div className="foll-name">{f.n}</div>
                  <span className="foll-role">{f.r}</span>
                </div>
              ))}
              <button className="inv-btn" onClick={() => showToast("Uitnodigingslink gekopieerd")}>+ Iemand uitnodigen</button>
            </div>
          </>}
        </div>

        {/* BOTTOM NAV */}
        <div className="bot-nav">
          {[{ id: "home", ic: "⊞", lbl: "Home" }, { id: "explore", ic: "◎", lbl: "Ontdek" }].map(t => (
            <button key={t.id} className={`bnav-tab ${nav === t.id ? "active" : ""}`} onClick={() => {
              if (t.id === "home") { setNav("home"); setTab("feed"); }
              else { setNav(t.id); showToast("Ontdek komt binnenkort"); }
            }}>
              <span className="bnav-ic">{t.ic}</span>{t.lbl}
            </button>
          ))}
          <button className="fab" onClick={() => setModal(true)}>+</button>
          {[{ id: "book", ic: "◧", lbl: "Fotoboek" }, { id: "profile", ic: "○", lbl: "Profiel" }].map(t => (
            <button key={t.id} className={`bnav-tab ${nav === t.id ? "active" : ""}`} onClick={() => {
              if (t.id === "book") { setNav("home"); setTab("ai"); } else setNav(t.id);
            }}>
              <span className="bnav-ic">{t.ic}</span>{t.lbl}
            </button>
          ))}
        </div>

        {modal && <Modal onClose={() => setModal(false)} onPost={addPost} />}
        {toast && <div className="toast">{toast}</div>}
      </div>
    </>
  );
}
